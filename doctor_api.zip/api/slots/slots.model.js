'use strict';

var mongoose = require("mongoose");
mongoose.Promise = Promise;
var Schema = mongoose.Schema;
var slotsSchema = new Schema({
    date : {
        type : Date,
        index : true
    },
    doctorId : {
        type : String,
        index : true
        
    },
    time_slot : Array,
   
    created_at: {
		type: Date,
		default: Date.now
	},
	modifed_at: {
		type: Date
    }
});

var SlotsModel = mongoose.model('Slots', slotsSchema);
module.exports = SlotsModel;