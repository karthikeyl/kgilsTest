'use strict';

var slotsModel = require('./slots.model');

var sendResp = require('../utils').sendResp
//Get the Slot for the selected Date
exports.index = function (req, res) {
    let daterange = formatDate(req.params.date)
    var q = {
        date: { $gte: daterange.start, $lte: daterange.end }
    }   
    slotsModel.find(q).exec(function(err, result) {
        if(err){
            console.log(err);
            sendResp(err, 500, "Slot get Error");
        }else{
            // console.log("slotDetails >>>>>>>",result.length)
            sendResp(res, 200, "Slot Details GET Successfully", {
                "slotDetails": result
            });
        }   
    })
    
}
//Create the slot if not exists else update the Existing Slot 
exports.create = function (req, res) {
    let params = req.body;
    let daterange = formatDate(params.selectedDate);
   let queryString =  { date: { $gte: daterange.start, $lte: daterange.end }, doctorId: params.doctorId };
   slotsModel.findOne(queryString).exec(function(err, result) {
    if (err) {
        console.log("create >>> find Error",err);
        sendResp(err, 500, "Slot processes Create Error");
    } else {
        console.log("result >>>>>> ",result);
        let timeSlotArray = result?result.time_slot : [];
        if (timeSlotArray.length > 0) {
            let found = false;
            let slotObj;
            for (const item of timeSlotArray) {
                if (calculateDate(params.selectedDate, item.stime, item.smin)<calculateDate(params.selectedDate, params.stime, item.smin) && calculateDate(params.selectedDate, item.etime, item.emin)<=calculateDate(params.selectedDate, params.stime, item.smin)) {
                    let tmp = {};
                    tmp["stime"] = params.stime;
                    tmp["smin"] = params.smin;
                    tmp["etime"] = params.etime;
                    tmp["emin"] = params.emin;
                    timeSlotArray.push(tmp);
                    slotObj = {
                        date: new Date(params.selectedDate),
                        time_slot: timeSlotArray,
                        doctorId: params.doctorId,
                        created: new Date(),
                        modifed: new Date()
                    }
                    found = true;
                    break;
                } 
            }
            if (found) {
                // console.log("found >>>>>> ",result);
                // update the Existing Slot 
                slotsModel.updateOne({_id:result._id},{$set:slotObj}).exec(function(error,result){
                    if(error){
                        console.log("updateOne >>>>>> error ",error);
                        sendResp(res, 500, "Slots Update erro",err);
                    }else{
                        console.log("updated Success  >>>>>> error ",result);
                        sendResp(res, 200, "Appointment processes GET Successfully", {
                            "slotDetails": result
                        });
                    }
                })
            } else {
                console.log("Not a Valid Time >>>>>>>>>")
                sendResp(res, 201, "Not a Valid Time");
            }
        } else {
            let tmp = {};
            tmp["stime"] = params.stime;
            tmp["smin"] = params.smin;
            tmp["etime"] = params.etime;
            tmp["emin"] = params.emin;
            timeSlotArray.push(tmp);
            let slotObj = {
                date: new Date(params.selectedDate),
                time_slot: timeSlotArray,
                doctorId: params.doctorId,
                created: new Date(),
                modifed: new Date()
            }
            let newslotsModel = new slotsModel(slotObj)
            // Crete the New Slot 
            newslotsModel.save(function (err, response) {
                if (err) {
                    console.log("slotsModel error >>>>>>>>>>>>>",err)
                    sendResp(err, 500, "Slots Save error " );
                } else {
                    console.log("Slot Creted Successfully >>>>>>>>>>>>> ",response)
                    sendResp(res, 200, "Slot Creted Successfully", {
                        "slotDetails": response
                    });
                }
            });
        }

    }
   })
}
//function to convert the date and get start and end Time
function formatDate(inputdate) {
    let date = new Date(inputdate)
    var year = date.getFullYear();
    var month = ("0" + (date.getMonth() + 1)).slice(-2);
    var day = ("0" + date.getDate()).slice(-2);
    let dateVar = year + "-" + month + "-" + day;
    var start = new Date(dateVar);
    start.setHours(0, 0, 0, 0);
    var end = new Date(dateVar);
    end.setHours(23, 59, 59, 999);
    return { start: start, end: end }
}
// function to calulate the differnce 
function calculateDate(date, time, min) {
    var currentTime = new Date(date);
    currentTime.setHours(time, min, 0, 0);
    var currentOffset = currentTime.getTimezoneOffset();
    var ISTOffset = 330;
    var ISTTime = new Date(currentTime.getTime() + (ISTOffset + currentOffset) * 60000);
    return ISTTime.getTime();
}
