'use strict';

var express = require("express");
var router = express.Router();
var slotsController = require('./slots.controller');

router.get('/:date',slotsController.index);
router.post('/create', slotsController.create);
module.exports = router;