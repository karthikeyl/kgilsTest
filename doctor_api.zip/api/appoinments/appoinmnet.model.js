'use strict';

var mongoose = require('mongoose');
mongoose.Promise = Promise;
var crypto = require('crypto');
var Schema = mongoose.Schema;

// Dashboard count Schema
var appointmentSchema = new Schema({
	doctorId: {
        type: String,
        index: true
    },
	patientName: {
        type: String,
        index: true
	},
	phoneNo: {
        type: String,
        index: true
	},	
	bokingTime: {
		type: String
    },
    waited: {
		type: Number
    }
});


var appointmentModel = mongoose.model('appointmentDetails', appointmentSchema);
module.exports = appointmentModel;