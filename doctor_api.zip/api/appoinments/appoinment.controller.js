'use strict';

var appointmentModel = require('./appoinmnet.model');

var utilsService = require('../utils')

exports.index = function(req, res) {
    
    appointmentModel.find({}).exec(function(err, result) {
		console.log("err >>>>>>",err)
        if (result&& result.length<=0) {
			console.log("No Data Found");
			utilsService.sendResp(res, 404, "No Data Found");
		}else if (!err) {
			console.log("Appointment processes GET Successfully",result.length);
			
            utilsService.sendResp(res, 200, "Appointment processes GET Successfully", {
					"appoinmentDetails": result
				});
		} else {
			console.log( "Appointment processes GET Error", err);
			utilsService.sendResp(res, 500, "Appointment processes GET Error");
		}

    })

}