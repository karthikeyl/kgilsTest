'use strict';

var express = require('express');
var controller = require('./appoinment.controller');
var router = express.Router();

router.get('/all',  controller.index);

module.exports = router; 