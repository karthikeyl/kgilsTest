console.log(process.env.AWS_MONGODB_URI,'...process.env.MONGOLAB_URI')
module.exports = {
    url : process.env.AWS_MONGODB_URI || 'mongodb://localhost:27017/test'
}