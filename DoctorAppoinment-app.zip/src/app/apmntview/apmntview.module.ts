import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ApmntviewRoutingModule } from './apmntview-routing.module';
import { ApmntviewComponent } from './apmntview.component';
import {SharedModule} from '../shared/shared.module';

@NgModule({
  declarations: [ApmntviewComponent],
  imports: [
    CommonModule,
    ApmntviewRoutingModule,
    SharedModule
  ]
})
export class ApmntviewModule { }
