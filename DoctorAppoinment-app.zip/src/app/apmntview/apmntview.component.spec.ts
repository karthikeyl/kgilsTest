import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApmntviewComponent } from './apmntview.component';

describe('ApmntviewComponent', () => {
  let component: ApmntviewComponent;
  let fixture: ComponentFixture<ApmntviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApmntviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApmntviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
