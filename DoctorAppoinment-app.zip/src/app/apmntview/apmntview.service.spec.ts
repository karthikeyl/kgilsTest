import { TestBed } from '@angular/core/testing';

import { ApmntviewService } from './apmntview.service';

describe('ApmntviewService', () => {
  let service: ApmntviewService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ApmntviewService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
