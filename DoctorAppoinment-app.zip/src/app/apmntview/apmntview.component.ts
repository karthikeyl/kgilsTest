import { Component, OnInit, ViewChild } from '@angular/core';
import { ApmntviewService } from './apmntview.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
@Component({
  selector: 'app-apmntview',
  templateUrl: './apmntview.component.html',
  styleUrls: ['./apmntview.component.scss']
})
export class ApmntviewComponent implements OnInit {
  navLinks = [
    { number: "06", disabled: false, item: "QUEU" },
    { number: "04", disabled: true, item: "EARILER" },
    { number: "07", disabled: true, item: "Wait List" },
    { number: "02", disabled: true, item: "SHOW" },
  ];
  displayedColumns: string[] = ['patitent', 'contact', 'appoinment', 'waited'];
  dataSource = new MatTableDataSource<any>();
  currentLink = "06";
  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(private apmntService: ApmntviewService) { }

  ngOnInit(): void {
    this.apmntService.getdetails().subscribe(data => {
      if (data) {
        this.dataSource = new MatTableDataSource<any>(data.response.appoinmentDetails);
        this.dataSource.paginator = this.paginator;
      }
    })
  }
  loadTabata(link) {
    this.currentLink = link.number;
  }

}
