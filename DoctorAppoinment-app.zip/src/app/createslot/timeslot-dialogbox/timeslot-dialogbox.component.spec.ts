import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TimeslotDialogboxComponent } from './timeslot-dialogbox.component';

describe('TimeslotDialogboxComponent', () => {
  let component: TimeslotDialogboxComponent;
  let fixture: ComponentFixture<TimeslotDialogboxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TimeslotDialogboxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TimeslotDialogboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
