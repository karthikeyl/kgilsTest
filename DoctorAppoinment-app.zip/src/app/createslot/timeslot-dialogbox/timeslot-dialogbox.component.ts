import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
@Component({
  selector: 'app-timeslot-dialogbox',
  templateUrl: './timeslot-dialogbox.component.html',
  styleUrls: ['./timeslot-dialogbox.component.scss']
})
export class TimeslotDialogboxComponent implements OnInit {
  minutes = [];
  times = []
  result = {};
  minute: any
  selectedTime= {
    stime: "10",
    smin: "30",
    etime: "11",
    emin: "30"
  }
  constructor(@Inject(MAT_DIALOG_DATA) public data) {
    if (data.session == "morning") {
      this.times = [9, 10, 11,12]
    } else {
      this.times = [17, 18, 19, 20, 21];
    }
  }

  ngOnInit(): void {
    for (let i = 0; i < 59; i++) {
      this.minutes.push(i);
    }
  }
  // selectTime(e) {
  //   if (this.selectedTime) {
  //     this.result["time"] = this.selectedTime
  //   }
  // }
  // selectMin(e) {
  //   if (this.minute) {
  //     this.result["min"] = this.minute;
  //   }
  // }
  get finalData() { return this.result }

}
