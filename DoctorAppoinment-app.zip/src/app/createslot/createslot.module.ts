import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CreateslotRoutingModule } from './createslot-routing.module';
import { CreateslotComponent } from './createslot.component';
import {SharedModule} from '../shared/shared.module';
import { TimeslotDialogboxComponent } from './timeslot-dialogbox/timeslot-dialogbox.component';

@NgModule({
  declarations: [CreateslotComponent, TimeslotDialogboxComponent],
  imports: [
    CommonModule,
    CreateslotRoutingModule,
    SharedModule
  ]
})
export class CreateslotModule { }
