import { Component, OnInit } from '@angular/core';
import { CreateslotService } from './createslot.service';
import { MatDialog } from '@angular/material/dialog';
import { TimeslotDialogboxComponent } from '../createslot/timeslot-dialogbox/timeslot-dialogbox.component'
@Component({
	selector: 'app-createslot',
	templateUrl: './createslot.component.html',
	styleUrls: ['./createslot.component.scss']
})
export class CreateslotComponent implements OnInit {
	selectedDate=new Date();
	morningData=[];
	eveningData=[]
	constructor(private createslotService: CreateslotService, private dialog: MatDialog) { }

	ngOnInit(): void {
		this.getData();
	}
	getData(){
		this.createslotService.getSlots(this.selectedDate).subscribe(data=>{
			console.log("data.response.slotDetails >>>>>>>>>>",data.response.slotDetails)
			if(data.response.slotDetails && data.response.slotDetails.length>0){
				this.morningData=[];
				this.eveningData=[];
				let tmpData=data.response.slotDetails;
				for (const item of tmpData[0].time_slot) {
					if(parseInt(item.stime)>=9 && parseInt(item.stime)<=12){
						this.morningData.push(item);
					}else{
						this.eveningData.push(item);
					}
				}
			}else{
				this.morningData=[];
				this.eveningData=[];
			}
		})
	}
	onSelect(event) {
		this.selectedDate = event;
		this.getData();
	}
	createSlot(session: string) {
		let params = {};
		params["selectedDate"] = this.selectedDate;
		params["session"] = session;
		params["doctorId"] = 1;
		const dialogRef = this.dialog.open(TimeslotDialogboxComponent,{data:{session:session}});
		dialogRef.afterClosed().subscribe(result => {
			let preparedata={
				...params,
				...result
			}
			this.createslotService.createSlot(preparedata).subscribe(data => {
				if(data.meta.status==200){
					this.getData();
				}else{
					alert(data.meta.msg)
				}
			}, error => {
				alert(error?.message)
				console.log("error >>>>> ",error);
			})
		});
	}
}
