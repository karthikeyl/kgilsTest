import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [
	{ path: "", redirectTo: "apmntview", pathMatch: "full" },
	{ path: 'apmntview', loadChildren: () => import('./apmntview/apmntview.module').then(m => m.ApmntviewModule) },
	{ path: 'createslot', loadChildren: () => import('./createslot/createslot.module').then(m => m.CreateslotModule) }
];

@NgModule({
	imports: [RouterModule.forRoot(routes)],
	exports: [RouterModule]
})
export class AppRoutingModule { }
