import { NgModule } from '@angular/core';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatButtonModule} from '@angular/material/button';
import {MatTabsModule} from '@angular/material/tabs';
import {MatTableModule} from '@angular/material/table';
import {MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { HeaderComponent } from './components/header/header.component';
import { HttpClientModule } from '@angular/common/http';
import {MatDialogModule} from '@angular/material/dialog';
import { FormsModule } from '@angular/forms';
import {MatPaginatorModule} from '@angular/material/paginator';
@NgModule({
	declarations: [HeaderComponent],
	imports: [MatNativeDateModule,MatGridListModule, MatToolbarModule, MatButtonModule, MatTabsModule, MatTableModule,MatNativeDateModule , MatDatepickerModule, HttpClientModule, MatDialogModule, FormsModule,MatPaginatorModule],
	exports: [HeaderComponent,MatGridListModule, MatToolbarModule, MatButtonModule, MatTabsModule, MatTableModule, MatDatepickerModule, HttpClientModule, MatDialogModule, FormsModule, MatPaginatorModule],
})
export class SharedModule { }