import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as moment from "moment";
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  currentDate= moment().format("DD-MMM-YYYY");
  constructor(private router: Router) { }

  ngOnInit(): void {
  }

  appoinment(){
    this.router.navigate(["/createslot"]);
  }
}
